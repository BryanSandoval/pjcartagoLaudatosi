var canvas = document.getElementById("game_canvas");
var stage = new createjs.Stage(canvas);

function Game(){
	this.state = "menu";
	this.player_count = 2;
	this.cur_player = 1;
	this.sound = false;
	this.preload;
	this.players = new createjs.Container();
	this.tile_size = 64;
	this.dice_sheet;
	this.p_head_sheet;
	this.p_head_sheet2;
	this.hand;
	this.return_count = 0;
	this.game_mode = "single";
	this.p_head = new createjs.Container();
	this.progress;
	this.arrayPosiciones = [];
	this.array_board = [ // [y][x] // -1 : serpiente // -2: escalera
		[0,-1,0,0,0,-1,0,-1,0,0],
		[0,0,0,0,0,0,-1,0,0,0],
		[0,0,0,0,0,0,0,0,0,-2],
		[0,-1,-2,-1,0,0,0,0,0,0],
		[0,0,0,0,0,0,-1,0,0,-2],
		[0,0,0,0,0,0,0,0,0,0],
		[-2,0,0,0,0,0,0,0,0,0],
		[0,0,0,0,0,0,0,-2,0,0],
		[-2,0,0,-1,0,0,0,0,0,0],
		[0,0,0,-2,0,-2,0,0,-2,0],
	];
	this.arrayPreguntasContestadas = [];
	this.array_pos_pregunta = {};
	
	var title;
	this.load = function(){
		createjs.Ticker.on("tick", this.update);
		createjs.Ticker.timingMode = createjs.Ticker.RAF;

		var title = new createjs.Bitmap();//new createjs.Bitmap("assets/img/logoJuego.png");
		title.setTransform(360, 400);
		title.regX = 593/2;
		title.regY = 351/2;

		this.progress = new createjs.Shape();
		this.progress.graphics.beginFill("#DBDBDB").drawRoundRect(0,0,570,32,6,6);
		this.progress.setTransform(75,660);

		stage.addChild(title, this.progress);
		manifest = [
			{src:"img/board.png", id:"board"},
			{src:"img/player1.png", id:"player_1"},
			{src:"img/player2.png", id:"player_2"},
			{src:"img/player3.png", id:"player_3"},
			{src:"img/player4.png", id:"player_4"},
			{src:"img/player5.png", id:"player_5"},
			{src:"img/player6.png", id:"player_6"},
			{src:"img/dice.png", id:"_dice"},
			{src:"img/player_head.png", id:"player_head"},
			//{src:"img/player_head_lg.png", id:"player_head_lg"},
			{src:"img/player_head_lg_2.png", id:"player_head_lg"},
			{src:"img/pos.png", id:"_pos"},
			{src:"img/pos_1.png", id:"pos_1"},
			{src:"img/pos_2.png", id:"pos_2"},
			{src:"img/pos_3.png", id:"pos_3"},
			{src:"img/pos_4.png", id:"pos_4"},
			{src:"img/hand.png", id:"hand"},
			{src:"img/btn_roll.png", id:"btn_roll"},
			{src:"img/btn_menu.png", id:"btn_menu"},
			{src:"img/btn_restart.png", id:"btn_restart"},
			{src:"img/btn_2.png", id:"btn_2"},
			{src:"img/btn_3.png", id:"btn_3"},
			{src:"img/btn_4.png", id:"btn_4"},
			{src:"img/btn_single.png", id:"btn_single"},
			{src:"img/boton_multi.png", id:"btn_multi"},
			{src:"img/logoJuego2.png", id:"game_title"},
			{src:"img/logoJuego.png", id:"logo_pj"},
			{src:"img/popup.png", id:"popup"},
			{src:"img/popup_pregunta.png", id:"popup_pregunta"},
			{src:"img/btn_opcion_pregunta.jpg", id:"btn_pregunta"},
			//Sound
			{src:"audio/move.mp3", id:"move"},
			{src:"audio/dice.mp3", id:"dice"},
			{src:"audio/ladder.mp3", id:"ladder"},
			{src:"audio/click.mp3", id:"click"},
			{src:"audio/snake.mp3", id:"snake"},
			{src:"audio/finish.mp3", id:"finish"},
			{src:"audio/hit.mp3", id:"hit"},
		];

		this.preload = new createjs.LoadQueue(true);
		this.preload.installPlugin(createjs.Sound);
		this.preload.on("complete", this.loaded.bind(this));
		this.preload.on("progress", this.onload.bind(this))
		this.preload.loadManifest(manifest, true, 'assets/');
		
	}
	this.onload = function(){
		this.progress.scaleX = this.preload.progress;
	}
	this.loaded = function(){
		stage.removeAllChildren();
		this.draw_menu();
	}
	this.img = function(id){
		return this.preload.getResult(id);
	}
	this.play_sound= function(id){
		if(this.sound){
			createjs.Sound.play(id);
		}
	}
	this.center = function(obj){
		obj.width = obj.getBounds().width;
		obj.height = obj.getBounds().height;

		obj.regX = obj.width/2;
		obj.regY = obj.height/2;
	}
	this.center_player = function(obj){
		obj.width = obj.getBounds().width;
		obj.height = obj.getBounds().height;

		obj.regX = obj.width/2;
		obj.regY = obj.height-25;
	}
	this.update = function(){
		stage.update();
	}
	this.draw_menu = function(){
		this.state = "menu";

		var buttons_menu = new createjs.Container();

		var highlight = new createjs.Shape();
		highlight.graphics.beginFill("#FFFF66").drawRect(-50, -5, 100, 30);
		highlight.x = 100;
		highlight.y = 100;

		var title = new createjs.Bitmap(this.img("game_title"));
		title.setTransform(360, 264);
		this.center(title);
		title.scaleX = title.scaleY = 1;

		var title2 = new createjs.Bitmap(this.img("logo_pj"));
		title2.setTransform(360, 264);
		this.center(title2);
		title.scaleX = title.scaleY = 1;

		createjs.Tween.get(title, {loop: -1, ignoreGlobalPause: true}) // get a tween targeting txt
				.to(title2, 2500) // change text after 1.5s // change text after 1.5s
				.to(title, 2500).set({visible: false}, highlight); // change text after 1.5s & set visible=true on highlight

		/*title = new createjs.Bitmap(this.img("game_title"));
		title.setTransform(360, 264);
		this.center(title);
		title.scaleX = title.scaleY = 0.2;
		//var emptImage =  new createjs.Bitmap(this.img("logo_pj"));

		createjs.Tween.get(title)
			.to({scaleX: 1, scaleY: 1}, 200, createjs.Ease.backOut);
			//.to({image: emptImage}, 0)
		//setTimeout(this.alert(), 1000);*/
		var nombreJuego =  new createjs.Text("Pastoral Juvenil Cartago", "bold 35px Arial");
		nombreJuego.setTransform(575, 400);
		nombreJuego.textAlign = "center";
		this.center(nombreJuego);
		nombreJuego.scaleX = nombreJuego.scaleY = 1;

		var nombreJuego2 =  new createjs.Text("Capitulo 2 Laudato' Si", "bold 35px Arial");
		nombreJuego2.setTransform(550, 450);
		nombreJuego2.textAlign = "center";
		this.center(nombreJuego2);
		nombreJuego2.scaleX = nombreJuego2.scaleY = 1;

		var b_single = new createjs.Bitmap(this.img("btn_single"));
		b_single.setTransform(360, 640);
		this.center(b_single);
		b_single.type = "single";

		var b_multi = new createjs.Bitmap(this.img("btn_multi"));
		b_multi.setTransform(360, 784);
		this.center(b_multi);
		b_multi.type = "multi";

		buttons_menu.addChild(b_single, b_multi);

		//Player count
		for(i=0; i<=2; i++){
			var id = i+4;
			var s = new createjs.Bitmap(this.img("btn_"+(id-2)));
			s.setTransform(960, 608+(140*i));
			this.center(s);
			s.type = i+4;
			buttons_menu.addChild(s);
		}
		/**
		 * i = 0 id= 4
		 * i = 1 id = 5
		 * i = 2 id = 6
		 */
		stage.addChild(nombreJuego, nombreJuego2, title, buttons_menu);
		buttons_menu.on("click", function(e){
			//this.play_sound("click");
			var target = e.target;

			createjs.Tween.get(target)
				.to({scaleX: 0.9, scaleY: 0.9}, 100)
				.to({scaleX: 1, scaleY: 1}, 100)
				.call(function(){
					if(target.type == "single" || target.type == "multi"){
						this.game_mode = target.type;
						tween_menu.bind(this)("main");
					} else {
						console.log("type: ", target.type);
						this.player_count = target.type;
						this.clear();
						this.game_init();
					}
				}.bind(this));

			function tween_menu(type){
				if(type == "main"){
					var count = 0;
					var interval = setInterval(function(){
						count++;
						var child = buttons_menu.getChildAt(count-1);
						createjs.Tween.get(child)
							.to({x: -360}, 400, createjs.Ease.backIn);
						if(count == 4){
							clearInterval(interval);
							tween_menu.bind(this)("mode");
						}
					}.bind(this), 100);
				} else if(type == "mode"){
					var count = 0;
					var interval = setInterval(function(){
						count++;
						var child = buttons_menu.getChildAt(count+1);
						createjs.Tween.get(child)
							.to({x: 360}, 500, createjs.Ease.backOut);
						if(count == 3){
							clearInterval(interval);
						}
					}.bind(this), 100);
				}
			}
		}.bind(this));
	}
	this.game_init = function(){

		this.state = "play";
		var game_buttons = new createjs.Container();
		document.addEventListener("keydown", function(e){
			var key = e.keyCode;
			var dice = this.roll_dice();
			if(key == 32){
				if(this.state == "play"){
					this.state = "move";
					this.spawn_dice(dice);
				}
			}
		}.bind(this));

		this.dice_sheet = new createjs.SpriteSheet({
			"images": [this.img("_dice")],
			"frames": {"width":236,"height":236,"count":6,"regX":236/2,"regY":236/2}
		});
		this.p_head_sheet = new createjs.SpriteSheet({
			"images": [this.img("player_head")],
			"frames": {"width":90,"height":90,"count":4,"regX":45,"regY":70}
		});
		this.p_head_sheet2 = new createjs.SpriteSheet({
			"images": [this.img("player_head_lg")],
			"frames": {"width":195,"height":200,"count":6,"regX":95,"regY":195}
			//"frames": {"width":195,"height":195,"count":6,"regX":97,"regY":195}
		});

		var board = new createjs.Bitmap(this.img("board"));
		board.setTransform(canvas.width/2, canvas.height/2);
		this.center(board);
		//console.log("this.array_board: ",this.array_board);
		//stage.addChild(s);
		/*var pos_t = new createjs.Bitmap(this.img("_pos"));
		pos_t.setTransform(76, 120);
		this.center(pos_t);*/

		//Generate pos
		/*for (j=1; j<=this.player_count; j++){
			var pos_n = new createjs.Bitmap(this.img("pos_"+j));
			pos_n.setTransform(56+(140*j), 120);
			this.center(pos_n);

			var head = new createjs.Sprite(this.p_head_sheet);
			head.gotoAndStop(j-1);
			head.setTransform(80+(140*j), 128)

			this.p_head.addChild(head);
			stage.addChild(pos_n);
		}*/

		for(i=1; i<=this.player_count; i++){
			var player = new createjs.Bitmap(this.img("player_"+i));
			player.step = [1,1];
			player.move = 0;
			player.first_move = true;
			player.pos_index = 0;
			player.frame = i-1;
			player.setTransform(board.x-(64*5)+(32+((i-1)*64)), board.y+(64*5)+50);
			this.center_player(player);
			this.players.addChild(player);
		}

		this.hand = new createjs.Bitmap(this.img("hand"));
		this.hand.setTransform(this.players.getChildAt(0).x, this.players.getChildAt(0).y - 90);
		this.center(this.hand);

		this.set_hand();

		var b_roll = new createjs.Bitmap(this.img("btn_roll"));
		b_roll.setTransform(360, 1000);
		this.center(b_roll);
		b_roll.type = "roll";

		var b_menu = new createjs.Bitmap(this.img("btn_menu"));
		b_menu.setTransform(80, 1000);
		this.center(b_menu);
		b_menu.type = "menu";

		game_buttons.addChild(b_roll, b_menu);

		game_buttons.on("click", function(e){
			var target = e.target;

			createjs.Tween.get(target)
				.to({scaleX: 0.9, scaleY: 0.9}, 100)
				.to({scaleX: 1, scaleY: 1}, 100)
				.call(function(){
					if(target.type == "roll"){
						if(this.state == "play"){
							this.state = "move";
							this.spawn_dice(this.roll_dice());
						}
					} else if(target.type == "menu"){
						//this.play_sound("click");
						this.clear();
						this.draw_menu();
					}
				}.bind(this))
		}.bind(this));

		//stage.addChild(board, this.players, pos_t, this.p_head, this.hand, game_buttons);
		stage.addChild(board, this.players, this.p_head, this.hand, game_buttons);
		this.array_pos_pregunta =  this.poner_preguntas_tablero(this.array_board);
		//console.log("this.array_pos_pregunta: ",this.array_pos_pregunta);
		//this.presentar_pregunta(16);
	}
	this.clear = function(){
		this.cur_player = 1;
		this.return_count = 0;
		this.players.removeAllChildren();
		this.p_head.removeAllChildren();
		stage.removeAllChildren();
	}
	this.spawn_dice = function(num){
		this.hand.alpha = 0;
		//this.play_sound("dice")

		var dice = new createjs.Sprite(this.dice_sheet);
		dice.gotoAndStop(num-1);
		dice.setTransform(canvas.width/2, canvas.height/2);
		dice.scaleX = dice.scaleY = 0;
		stage.addChild(dice);

		createjs.Tween.get(dice)
			.to({scaleX: 1, scaleY: 1}, 300, createjs.Ease.backOut)
			.to({scaleX: 0, scaleY: 0}, 300, createjs.Ease.backIn)
			.call(function(){
				stage.removeChild(dice);
				this.move(num, this.players.getChildAt(this.cur_player-1));
			}.bind(this));
	}
	this.set_hand = function(){
		this.hand.x = this.players.getChildAt(this.cur_player-1).x;
		this.hand.y = this.players.getChildAt(this.cur_player-1).y-90;
		this.hand.alpha = 1;
		var t_y = this.hand.y - 15;
		createjs.Tween.get(this.hand, {loop: true, bounce: true})
			.to({y: t_y}, 200)
	}
	this.move = function(step, obj){
		this.state = "move";
		var dirrection = "none";
		if(obj.step[1] == 1 || obj.step[1] == 3 || obj.step[1] == 5 || obj.step[1] == 7 || obj.step[1] == 9){
			dirrection = "right";
		} else {
			dirrection = "left";
		}

		if(dirrection == "right"){
			if(obj.step[0] + step <= 10){
				obj.move = step;
				obj.pos_index += step;
				move_player.bind(this)(obj, dirrection);

			} else {
				obj.move = step;
				obj.pos_index += step;
				move_player.bind(this)(obj, "up-left");
			}
		} else {
			if(obj.step[0] - step > 0){
				obj.move = step;
				obj.pos_index += step;
				move_player.bind(this)(obj, dirrection);
			} else {
				obj.move = step;
				obj.pos_index += step;
				move_player.bind(this)(obj, "up-right");
			}
		}

		function move_player(obj, to){
			var move_to = to;
			var target_x;
			var target_x2;
			var target_y;
			if(move_to == "right"){
				if(obj.first_move == true){
					obj.first_move = false;
					target_x = obj.x;
					target_x2 = 72;
					target_y = 828-32;
				} else {
					obj.step[0]++;
					target_x = obj.x + this.tile_size - 32;
					target_x2 = obj.x + this.tile_size;
					target_y = obj.y - 32;
				}
			} else if(move_to == "left"){
				obj.step[0]--;
				target_x = obj.x - this.tile_size + 32;
				target_x2 = obj.x - this.tile_size;
				target_y = obj.y - 32;
			} else if(move_to == "up-left"){
				if(obj.step[0] < 10){
					obj.step[0]++;
					target_x = obj.x + this.tile_size - 32;
					target_x2 = obj.x + this.tile_size;
					target_y = obj.y - 32;
				} else if(obj.step[0] == 10){
					obj.step[1]++;
					target_x = obj.x;
					target_x2 = obj.x;
					target_y = obj.y - 96;
					move_to = "left";
				}
			
			} else if(move_to == "up-right"){
				if(obj.step[1] == 10 && obj.step[0] == 1){
					obj.step[0]++;
					target_x = obj.x + this.tile_size - 32;
					target_x2 = obj.x + this.tile_size;
					target_y = obj.y - 32;
					move_to = "right";
				} else {
					if(obj.step[0] > 1){
						obj.step[0]--;
						target_x = obj.x - this.tile_size + 32;
						target_x2 = obj.x - this.tile_size;
						target_y = obj.y - 32;
					} else if(obj.step[0] == 1){
						obj.step[1]++;
						target_x = obj.x;
						target_x2 = obj.x;
						target_y = obj.y - 96;
						move_to = "right";
					}
				}	
			}

			createjs.Tween.get(obj)
					.to({x: target_x, y: target_y},200, createjs.Ease.powOut)
					.to({x: target_x2, y: target_y+32},200, createjs.Ease.powIn)
					.call(function(){
						//this.play_sound("move");
						if(obj.move > 1){
							obj.move--;
							move_player.bind(this)(obj, move_to);
						} else {
							this.check_move(obj);
						}
					}.bind(this));
		}
	}
	this.player_stats = function(){
		//var p_array = [0,0,0,0];
		var p_array = [
			[0,0],
			[0,0],
			[0,0],
			[0,0],
			[0,0],
			[0,0]
		];

		for(i=0; i<this.player_count; i++){
			var child = this.players.getChildAt(i);
			p_array[i][0] = i;
			p_array[i][1] = child.pos_index;
		}

		p_array.sort(function(a,b){
			return b[1]-a[1];
		});

		/*for(j=0; j<this.player_count; j++){
			var child = this.p_head.getChildAt(j);
			child.gotoAndStop(p_array[j][0]);
		}*/
	}
	this.check_move = function(obj){
		var child = obj;
		var x = obj.step[0];
		var y = obj.step[1];
		var pos_y = 10-y;
		var can_move = false;
		var move_type = "";
		var hay_pregunta = false;
		var numero_pregunta = 0;
		//evalua pregunta
		
		//
		//console.log("this.array_board[pos_y][x-1]: ",this.array_board[pos_y][x-1]);
		//console.log("x: ", x, " y: ",y, "pos_y: ", pos_y);
		for (const key in this.array_pos_pregunta) {
			if (this.array_pos_pregunta.hasOwnProperty(key)) {
				let element = JSON.stringify(this.array_pos_pregunta[key]);
				let objeto = JSON.parse(element);
				//console.log("objeto x: ", objeto.x, " y: ",objeto.y);
				// evalua si hay pregunta en esa casilla
				if(objeto.x == pos_y && objeto.y == x-1 )
				{
					//console.log("arrayContestadas: ", this.arrayPreguntasContestadas.length);
					if (this.compruebaPreguntaContestada(objeto.num_pregunta) == 0){
						hay_pregunta = true;
						numero_pregunta = objeto.num_pregunta;
					}
					else{
						hay_pregunta = false;
						//numero_pregunta = objeto.num_pregunta;
					}
					
				}
			}
		}
		
		if(this.array_board[pos_y][x-1] == -2){ //Ladder
			if(y == 1 && x == 4){
				obj.step[0] = 7;
				obj.step[1] = 2;
				obj.pos_index = 14;
				can_move = true;
				move_type = "ladder";
			} else if(y == 1 && x == 9){
				obj.step[0] = 10;
				obj.step[1] = 4;
				obj.pos_index = 31;
				can_move = true;
				move_type = "ladder";
			} else if(y == 2 && x == 1){
				obj.step[0] = 3;
				obj.step[1] = 4;
				obj.pos_index = 38;
				can_move = true;
				move_type = "ladder";
			} else if(y == 3 && x == 8){
				obj.step[0] = 4;
				obj.step[1] = 9;
				obj.pos_index = 84;
				can_move = true;
				move_type = "ladder";
			} else if(y == 4 && x == 1){
				obj.step[0] = 2;
				obj.step[1] = 6;
				obj.pos_index = 59;
				can_move = true;
				move_type = "ladder";
			} else if(y == 6 && x == 10){
				obj.step[0] = 7;
				obj.step[1] = 7;
				obj.pos_index = 67;
				can_move = true;
				move_type = "ladder";
			} else if(y == 7 && x == 3){
				obj.step[0] = 1;
				obj.step[1] = 9;
				obj.pos_index = 81;
				can_move = true;
				move_type = "ladder";
			} else if(y == 8 && x == 10){
				obj.step[0] = 10;
				obj.step[1] = 10;
				obj.pos_index = 91;
				can_move = true;
				move_type = "ladder";
			}
		} else if(this.array_board[pos_y][x-1] == -1){ //Snake
			if(y == 2 && x == 4){
				obj.step[0] = 7;
				obj.step[1] = 1;
				obj.pos_index = 7;
				can_move = true;
			} else if(y == 6 && x == 7){
				obj.step[0] = 7;
				obj.step[1] = 4;
				obj.pos_index = 34;
				can_move = true;
			} else if(y == 7 && x == 2){
				obj.step[0] = 2;
				obj.step[1] = 2;
				obj.pos_index = 19;
				can_move = true;
			} else if(y == 7 && x == 4){
				obj.step[0] = 1;
				obj.step[1] = 6;
				obj.pos_index = 60;
				can_move = true;
			} else if(y == 9 && x == 7){
				obj.step[0] = 4;
				obj.step[1] = 3;
				obj.pos_index = 24;
				can_move = true;
			} else if(y == 10 && x == 8){
				obj.step[0] = 8;
				obj.step[1] = 8;
				obj.pos_index = 73;
				can_move = true;
			} else if(y == 10 && x == 6){
				obj.step[0] = 6;
				obj.step[1] = 8;
				obj.pos_index = 75;
				can_move = true;
			} else if(y == 10 && x == 2){
				obj.step[0] = 3;
				obj.step[1] = 8;
				obj.pos_index = 78;
				can_move = true;
			}
		}

		if(hay_pregunta == true)
		{
			this.presentar_pregunta(numero_pregunta);
		}

		if(can_move){
			/*if(move_type == "ladder"){
				this.play_sound("ladder");
			} else {
				this.play_sound("snake");
			}*/
			var target_x = 72 + (obj.step[0]-1) * this.tile_size;
			var target_y = 188 + (11 - obj.step[1]) * this.tile_size;
			createjs.Tween.get(obj)
				.to({x: target_x, y: target_y}, 400)
				.call(function(){
					this.state = "play";
					//this.player_stats();
					this.player_return();
				}.bind(this));
		} else {
			if(obj.step[0] == 1 && obj.step[1] == 10){
				this.winner();
			} else {
				this.state = "play";
				//this.player_stats();
				this.player_return();
			}	
		}
	}
	this.presentar_pregunta = function(numero_pregunta){
		var descTextoPregunta = null;
		var vent_pregunta = new createjs.Bitmap(this.img("popup_pregunta"));
		vent_pregunta.setTransform(360, 540);
		this.center(vent_pregunta);
		var textoPregunta;
		var textoPreguntaOp1;
		var textoPreguntaOp2;
		var textoPreguntaOp3;
		var textoPreguntaOp4;
		var cont_botones_pregunta = new createjs.Container();
		var btnOpcion1 = new createjs.Bitmap(this.img("btn_pregunta"));
		var btnOpcion2 = new createjs.Bitmap(this.img("btn_pregunta"));
		var btnOpcion3 = new createjs.Bitmap(this.img("btn_pregunta"));
		var btnOpcion4 = new createjs.Bitmap(this.img("btn_pregunta"));
		var opcionCorrecta = "";
		this.cargar_json(function(respuesta){
			var actual_JSON = JSON.parse(respuesta);
			for (const key in actual_JSON) {
				if (actual_JSON.hasOwnProperty(key)) {
					let element = JSON.stringify(actual_JSON[key]);
					let pregunta = JSON.parse(element);
					//console.log("pregunta: ", pregunta, "desc: ",pregunta.Desc_Pregunta, " idPregunta: ",pregunta.idPregunta);
					//alert("Pregunta: "+pregunta.Desc_Pregunta +" ,pregunta.idPregunta: "+pregunta.idPregunta);
					if(pregunta.idPregunta == numero_pregunta)
					{
						opcionCorrecta = pregunta.Opcion_Correcta;
						descTextoPregunta = pregunta.Desc_Pregunta;
						textoPregunta = new createjs.Text(pregunta.Desc_Pregunta, "20px Arial", "#1F7096");
						textoPregunta.x = 365;
						textoPregunta.y = 350;
						textoPregunta.lineWidth = 325;
						textoPregunta.textAlign = 'center';
						
						textoPreguntaOp1 = new createjs.Text(pregunta.Opcion1, "14px Arial", "#006990");
						textoPreguntaOp2 = new createjs.Text(pregunta.Opcion2, "14px Arial", "#006990");
						textoPreguntaOp3 = new createjs.Text(pregunta.Opcion3, "14px Arial", "#006990");
						textoPreguntaOp4 = new createjs.Text(pregunta.Opcion4, "14px Arial", "#006990");
						textoPreguntaOp1.x = 195;
						textoPreguntaOp1.y = 475;
						textoPreguntaOp1.lineWidth = 300;

						textoPreguntaOp2.x = 195;
						textoPreguntaOp2.y = 535;
						textoPreguntaOp2.lineWidth = 300;

						textoPreguntaOp3.x = 195;
						textoPreguntaOp3.y = 595;
						textoPreguntaOp3.lineWidth = 300;

						textoPreguntaOp4.x = 195;
						textoPreguntaOp4.y = 655;
						textoPreguntaOp4.lineWidth = 300;

						btnOpcion1.setTransform(190, 465);
						btnOpcion2.setTransform(190, 525);
						btnOpcion3.setTransform(190, 585);
						btnOpcion4.setTransform(190, 645);
						
						btnOpcion1.tipo = "opcion1"; 
						btnOpcion2.tipo = "opcion2"; 
						btnOpcion3.tipo = "opcion3"; 
						btnOpcion4.tipo = "opcion4"; 
						cont_botones_pregunta.addChild(textoPregunta, btnOpcion1, btnOpcion2, btnOpcion3, btnOpcion4, textoPreguntaOp1, textoPreguntaOp2, textoPreguntaOp3,textoPreguntaOp4); 
						stage.addChild(vent_pregunta, cont_botones_pregunta);
					}
				}
			}
		});

		cont_botones_pregunta.on("click", function(e){
			var target = e.target;
			var correcta =  target.tipo == opcionCorrecta ? 'correcta' : 'incorrecta';
			this.arrayPreguntasContestadas[this.arrayPreguntasContestadas.length] = {num_pregunta_contestada: numero_pregunta, correcta: correcta};
			vent_pregunta.visible = false;
			alert("La opción escogida es "+correcta);
			cont_botones_pregunta.visible = false;
		}.bind(this))
		//(descTextoPregunta == undefined ? "NULO": descTextoPregunta)
		
	}

	this.winner = function(){
		//this.play_sound("finish");
		this.state = "win";
		var win = new createjs.Bitmap(this.img("popup"));
		win.setTransform(360, 540);
		this.center(win);

		var btn = new createjs.Container();

		var s = new createjs.Sprite(this.p_head_sheet2);
		s.gotoAndStop(this.cur_player-1);
		s.setTransform(360, 640);

		var b_restart = new createjs.Bitmap(this.img("btn_restart"));
		b_restart.setTransform(240, 688);
		this.center(b_restart);
		b_restart.type = "restart";

		var b_menu = new createjs.Bitmap(this.img("btn_menu"));
		b_menu.setTransform(480, 688);
		this.center(b_menu);
		b_menu.type = "menu";

		btn.addChild(b_restart, b_menu);

		stage.addChild(win, s, btn);

		btn.on("click", function(e){
			//this.play_sound("click");
			var target = e.target;
			createjs.Tween.get(target)
				.to({scaleX: 0.9, scaleY: 0.9}, 100)
				.to({scaleX: 1, scaleY: 1}, 100)
				.call(function(){
					if(target.type == "restart"){
						this.clear();
						btn.removeAllChildren();
						this.game_init();
					} else if(target.type == "menu"){
						this.clear();
						btn.removeAllChildren();
						this.draw_menu();
					}
				}.bind(this))
		}.bind(this))
	}
	this.roll_dice = function(){
		if(this.return_count > this.player_count){
			return Math.round(Math.random()*5)+1;
		} else {
			return Math.round(Math.random()*4)+2;
		}
	}
	this.player_return = function(){
		//console.log("jugador retorno");
		this.return_count++;
		if(this.cur_player < this.player_count){

			if(this.check_overlap() == false){
				this.cur_player++;
				if (this.game_mode == "single") {
					this.move(this.roll_dice(), this.players.getChildAt(this.cur_player-1));
				} else {
					this.set_hand();
				}
				
			} else {
				this.cur_player++;
			}
			
		} else {
			if(this.check_overlap() == false){
				this.cur_player = 1;
				this.set_hand();

				if (this.return_count > 30){
					this.return_count = 3;
				}
			} else {
				this.cur_player = 1;
			}
			
		}
	}
	this.check_overlap = function(){
		var cur_index = this.cur_player -1;
		var obj = this.players.getChildAt(cur_index);
		var count = this.players.numChildren;
		var x = obj.step[0];
		var y = obj.step[1];
		var is_drop = false;
		for(i=0; i<count; i++){
			if(i != cur_index){
				var child = this.players.getChildAt(i);
				if(child.step[0] == x && child.step[1] == y){
					this.state = "drop";
					this.drop_player(child);
					//is_drop = true;
					break;
				}
			}
		}
		return is_drop;
	}
	this.drop_player = function(obj){
		//this.play_sound("hit");
		this.player_stats();
		this.state = "play";
		this.set_hand();
		return;
		createjs.Tween.get(obj)
			.to({x: 72, y: 828}, 500)
			.call(function(){
				//bj.step[0] = 1;
				//obj.step[1] = 1;
				//obj.pos_index = 1;
				this.player_stats();
				this.state = "play";
				if(this.cur_player != 1){
					if(this.game_mode == "single") {
						this.move(this.roll_dice(), this.players.getChildAt(this.cur_player-1));
					} else {
						this.set_hand();
					}
				} else {
					this.set_hand();
				}
			}.bind(this))
	}

	this.cargar_json = function(callback)
	{
		var xobj = new XMLHttpRequest();
        xobj.overrideMimeType("application/json");
    	xobj.open('GET', '/assets/datos/preguntas_juego.json', true); // Replace 'my_data' with the path to your file
    	xobj.onreadystatechange = function () {
          if (xobj.readyState == 4 && xobj.status == "200") {
            // Required use of an anonymous callback as .open will NOT return a value but simply returns undefined in asynchronous mode
            callback(xobj.responseText);
          }
    	};
    	xobj.send(null); 
	}

	this.poner_preguntas_tablero = function(param_array_board)
	{
		var arrayPosicionesPreg = [];
		var array_copia = param_array_board;
		this.cargar_json(function(respuesta){
			var actual_JSON = JSON.parse(respuesta);
			var arrayPreguntas = [];
			var existe = false;
			var existe_pregunta = false;
			var posTablero_x = 1;
			var posTablero_y = 1;
			var contador = 12;
			var random_pregunta = 0;

			numeros = new Array(); //array dónde almacenar los seis números
			minimo = 1; //valor mínimo posible
			maximo = actual_JSON.length; //valor máximo posible


			for (i=0;i<actual_JSON.length;i++){
				temp = Math.round(Math.random() * maximo); //generanos número aleatorio
				temporal = parseInt((Math.floor(temp))+1); //redondeamos, para evitar decimales
				if ((temporal >= minimo) && (temporal <= maximo)) {
					// Si el elemento no se encuentra en numeros[] agregamos (push), en caso
					// de que si se encuentre (continue;), saltar al siguente numero, restando
					// uno al contador del for.
					if(numeros.indexOf(temporal)!=-1){
						i--; //en caso de valor incorrecto se descuenta uno para que salgan 6 valores
						continue;
					} else {
						numeros.push(temporal); //agregamos al array el número de temporal
					}

				}else{
						i--;//en caso de valor incorrecto se descuenta uno para que salgan 6 valores
						continue;
				}

			}

			while (arrayPosicionesPreg.length != 12)
			{
				posTablero_x = Math.ceil(Math.random()*9);
				posTablero_y = Math.ceil(Math.random()*10);
				
				var obj = {posTablero_x, posTablero_y};
				//console.log("posTablero: ",posTablero);
				for(var i=0;i<arrayPosicionesPreg.length;i++){
					if(arrayPosicionesPreg [i] == obj){
						existe = true;
						break;
					}
				}
				if(!existe){
					var numero = numeros[arrayPosicionesPreg.length];
					arrayPosicionesPreg[arrayPosicionesPreg.length] = {x: posTablero_x, y: posTablero_y, num_pregunta: numero};
					//break;
				}
			}
			/*console.log("ARRAY: ",arrayPosicionesPreg);
		for (let index = 0; index < arrayPosicionesPreg.length; index++) {
				console.log("arrayPosicionesPreg[index]: "+JSON.stringify(arrayPosicionesPreg[index]));
				const posicion_preg = JSON.stringify(arrayPosicionesPreg[index]);
				this.array_board[posicion_preg.x][posicion_preg.y] = posicion_preg.num_pregunta;
			}
			//this.array_copia = this.array_board;
			
			for (const key in arrayPosicionesPreg) {
				if (arrayPosicionesPreg.hasOwnProperty(key)) {
					let element = JSON.stringify(arrayPosicionesPreg[key]);
					let objeto = JSON.parse(element);
					//array_copia[objeto.y][objeto.x] = objeto.num_pregunta;
					//this.array_board[pos_y][x-1]
					//console.log("this.array_board: ",this.array_board[objeto.x][objeto.y]);
				}
			}
			this.array_pos_pregunta
			console.log("array_copia: ", array_copia);*/
			
		});
		
		return arrayPosicionesPreg;
	}

	this.compruebaPreguntaContestada = function(numeroPregunta)
	{
		//alert("PIDE");
		for (let index = 0; index < this.arrayPreguntasContestadas.length; index++) {
			let element = JSON.stringify(this.arrayPreguntasContestadas[index]);
			//console.log("element: "+element);
			let preguntaContestada = JSON.parse(element);
			//console.log("preguntaContestada: "+preguntaContestada.num_pregunta_contestada);
			if(preguntaContestada.num_pregunta_contestada == numeroPregunta)
			{
				if(preguntaContestada == 'correcta') {
					return 1;// ya fue contestada
				}
				else{
					return 0; // ya fue contestada pero de forma incorrecta
				}
				 
			}
		}

		return 0;
	}
}

var p = new Game();
function init(){
	p.load();
}

(function () {
  
  var game = {
	  element: document.getElementById("game_canvas"),
	  width: canvas.width,
	  height: canvas.height
  },
  
  resizeGame = function () {
		
	  var viewport, newGameWidth, newGameHeight, newGameX, newGameY;
				
	  // Get the dimensions of the viewport
	  viewport = {
		  width: window.innerWidth,
		  height: window.innerHeight
	  };
	  
	  // Determine game size
	  if (game.height / game.width > viewport.height / viewport.width) {
		newGameHeight = viewport.height;
		newGameWidth = newGameHeight * game.width / game.height;  
	  } else {
		newGameWidth = viewport.width;
		newGameHeight = newGameWidth * game.height / game.width;		 
	  }
  
	  game.element.style.width = newGameWidth + "px";
	  game.element.style.height = newGameHeight + "px";
	  
	  newGameX = (viewport.width - newGameWidth) / 2;
	  newGameY = (viewport.height - newGameHeight) / 2;

	  // Set the new padding of the game so it will be centered
	  game.element.style.padding = newGameY + "px " + newGameX + "px";
  };
  
  window.addEventListener("resize", resizeGame);
  resizeGame();
}())
